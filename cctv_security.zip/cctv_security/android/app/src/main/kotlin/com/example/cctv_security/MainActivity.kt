package com.example.cctv_security

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
