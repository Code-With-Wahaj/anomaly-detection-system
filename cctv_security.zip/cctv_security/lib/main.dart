
// main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'detection_provider.dart';
import 'scenario_camera_view.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => DetectionProvider(), // Still providing it, can be used for global state
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Multi-Cam CCTV Detection',
      theme: ThemeData(
        primarySwatch: Colors.indigo, // Updated theme color
        visualDensity: VisualDensity.adaptivePlatformDensity,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.indigo[700],
          elevation: 4,
        ),
        tabBarTheme: TabBarTheme(
          labelColor: Colors.white,
          unselectedLabelColor: Colors.indigo[200],
          indicatorSize: TabBarIndicatorSize.tab,
          indicator: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(10),
              topRight: Radius.circular(10),
            ),
            color: Colors.indigo[500],
          ),
        ),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CCTV Monitoring System'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.videocam), text: "Cam 1"),
            Tab(icon: Icon(Icons.group_work), text: "Cam 2"),
            Tab(icon: Icon(Icons.security), text: "Cam 3"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        // Prevent tabs from being disposed when not active to maintain state (e.g., video stream)
        // This can be resource-intensive. Consider if this is desired or if state needs saving/restoring.
        // For simplicity now, we keep them alive.
        physics: const NeverScrollableScrollPhysics(), // Disable swipe to change tabs
        children: const [
          ScenarioCameraView(scenarioType: ScenarioType.cam1_unattended_luggage, cameraName: "Camera 1"),
          ScenarioCameraView(scenarioType: ScenarioType.cam2_boarding_lanes, cameraName: "Camera 2"),
          ScenarioCameraView(scenarioType: ScenarioType.cam3_restricted_zone, cameraName: "Camera 3"),
        ],
      ),
    );
  }
}

